package com.sample.in;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomatedAttendanceSysyemApplicationTests {

	@Test
	void contextLoads() {
	}

}
