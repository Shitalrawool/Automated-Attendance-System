package com.sample.in.Service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sample.in.Entity.Faculty;
import com.sample.in.Repository.FacultyRepository;
import com.sample.in.Service.FacultyService;

@Service
public class FacultyServiceImpl implements FacultyService{

	private FacultyRepository facultyRepository;
	
	public FacultyServiceImpl(FacultyRepository facultyRepository) {
		super();
		this.facultyRepository = facultyRepository;
	}

	@Override
	public List<Faculty> getAllFacultys() {
		return facultyRepository.findAll();
	}

	@Override
	public Faculty saveFaculty(Faculty faculty) {
		return facultyRepository.save(faculty);
	}

	@Override
	public Faculty getFacultyById(Long id) {
		return facultyRepository.findById(id).get();
	}

	@Override
	public Faculty updateFaculty(Faculty faculty) {
		return facultyRepository.save(faculty);
	}

	@Override
	public void deleteFacultyById(Long id) {
		facultyRepository.deleteById(id);	
	}


}
