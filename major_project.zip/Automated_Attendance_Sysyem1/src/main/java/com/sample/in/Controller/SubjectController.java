package com.sample.in.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.sample.in.Entity.Subject;
import com.sample.in.Service.SubjectService;


@Controller
public class SubjectController {
	
		
		private SubjectService subjectService;

		public SubjectController(SubjectService subjectService) {
			super();
			this.subjectService = subjectService;
		}
		
		// handler method to handle list subject and return mode and view
		@GetMapping("/subjects")
		public String listSubjects(Model model) {
			model.addAttribute("subjects", subjectService.getAllSubjects());
			return "subjects";
		}
		
		@GetMapping("/subjects/new")
		public String createSubjectForm(Model model) {
			
			// create subject object to hold subject form data
			Subject subject = new Subject();
			model.addAttribute("subject", subject);
			return "create_subject";
			
		}
		
		@PostMapping("/subjects")
		public String saveSubject(@ModelAttribute("subject") Subject subject) {
			subjectService.saveSubject(subject);
			return "redirect:/subjects";
		}
		
		@GetMapping("/subjects/edit/{id}")
		public String editSubjectForm(@PathVariable Long id, Model model) {
			model.addAttribute("subject", subjectService.getSubjectById(id));
			return "edit_subject";
		}

		@PostMapping("/subjects/{id}")
		public String updateSubject(@PathVariable Long id,
				@ModelAttribute("subject") Subject subject,
				Model model) {
			
			// get subject from database by specific id.
			Subject existingSubject = subjectService.getSubjectById(id);
			existingSubject.setId(id);
			existingSubject.setSubjectName(subject.getSubjectName());
			existingSubject.setSemester(subject.getSemester());
			existingSubject.setYear(subject.getYear());
			
			
			
			// save updated subject object
			subjectService.updateSubject(existingSubject);
			return "redirect:/subjects";		
		}
		
		// handler method to handle delete subject request
		
		@GetMapping("/subjects/{id}")
		public String deleteSubject(@PathVariable Long id) {
			subjectService.deleteSubjectById(id);
			return "redirect:/subjects";
		}

}
