package com.sample.in.Service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sample.in.Entity.Subject;
import com.sample.in.Repository.SubjectRepository;
import com.sample.in.Service.SubjectService;

@Service
public class SubjectServiceImpl implements SubjectService {
	


		private SubjectRepository subjectRepository;
		
		public SubjectServiceImpl(SubjectRepository subjectRepository) {
			super();
			this.subjectRepository = subjectRepository;
		}

		@Override
		public List<Subject> getAllSubjects() {
			return subjectRepository.findAll();
		}

		@Override
		public Subject saveSubject(Subject subject) {
			return subjectRepository.save(subject);
		}

		@Override
		public Subject getSubjectById(Long id) {
			return subjectRepository.findById(id).get();
		}

		@Override
		public Subject updateSubject(Subject subject) {
			return subjectRepository.save(subject);
		}

		@Override
		public void deleteSubjectById(Long id) {
			subjectRepository.deleteById(id);	
		}



}
