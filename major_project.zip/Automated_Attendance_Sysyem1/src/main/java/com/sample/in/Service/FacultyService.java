package com.sample.in.Service;

import java.util.List;

import com.sample.in.Entity.Faculty;

public interface FacultyService {
	
	List<Faculty> getAllFacultys();
	
	Faculty saveFaculty(Faculty faculty);
	
	Faculty getFacultyById(Long id);
	
	Faculty updateFaculty(Faculty faculty);
	
	void deleteFacultyById(Long id);

}
