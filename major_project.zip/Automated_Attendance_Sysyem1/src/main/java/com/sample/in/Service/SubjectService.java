package com.sample.in.Service;

import java.util.List;
import com.sample.in.Entity.Subject;

public interface SubjectService {
	
List<Subject> getAllSubjects();
	
	Subject saveSubject(Subject subject);
	
	Subject getSubjectById(Long id);
	
	Subject updateSubject(Subject subject);
	
	void deleteSubjectById(Long id);
	
	
	
	
	    
	    

}
