package com.sample.in.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HtmlController {
	
	
	@GetMapping("/student_s")
	public String students() {
		return "students";
	}
	
	@GetMapping("/subject_s")
	public String subjects() {
		return "subjects";
			}
			
	@GetMapping("/faculty_s")
	public String facultys() {
		return "facultys";
			}
				
	@GetMapping("/attendance_s")
	public String attendances() {
		return "attendances";
				}
	
	@GetMapping("/logout")
	public String logout() {
		return "redirect:/html1";
	}
	
	@RequestMapping(value= "/html1", method = RequestMethod.GET)
	public String html()
	{
		return "html1";
	}
	
	@PostMapping("/html1")
	public String Welcome(ModelMap model,@RequestParam String userId,@RequestParam String password) {
		if(userId.equals("admin") && password.equals("root")){
			model.put("userId", userId);
			return "Welcome";
		}
		else {
		model.put("errorMsg", "Please provide the correct userid and password");
		return "html1";
		}
}

}
