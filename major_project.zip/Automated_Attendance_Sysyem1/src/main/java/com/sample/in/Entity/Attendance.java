package com.sample.in.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "attendance")
public class Attendance {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "dateOfLecture", nullable = false)
	private String dateOfLecture;
	
	@Column(name = "time")
	private String time;
	
	@Column(name = "status")
	private String status;
	

//Mapping for Student and attendance for overall attendance.
	
	@ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;

//Mapping for Subject and attendance for overall attendance
	
    @ManyToOne
    @JoinColumn(name = "subject_id")
    private Subject subject;

    
 //Mapping for Faculty and attendance for overall attendance
    @ManyToOne
    @JoinColumn(name = "faculty_id")
    private Faculty faculty;


	public Attendance() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Attendance(Long id, String dateOfLecture, String time, String status, Student student, Subject subject,
			Faculty faculty) {
		super();
		this.id = id;
		this.dateOfLecture = dateOfLecture;
		this.time = time;
		this.status = status;
		this.student = student;
		this.subject = subject;
		this.faculty = faculty;
	}


	@Override
	public String toString() {
		return "Attendance [id=" + id + ", dateOfLecture=" + dateOfLecture + ", time=" + time + ", status=" + status
				+ ", student=" + student + ", subject=" + subject + ", faculty=" + faculty + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getDateOfLecture() {
		return dateOfLecture;
	}


	public void setDateOfLecture(String dateOfLecture) {
		this.dateOfLecture = dateOfLecture;
	}


	public String getTime() {
		return time;
	}


	public void setTime(String time) {
		this.time = time;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Student getStudent() {
		return student;
	}


	public void setStudent(Student student) {
		this.student = student;
	}


	public Subject getSubject() {
		return subject;
	}


	public void setSubject(Subject subject) {
		this.subject = subject;
	}


	public Faculty getFaculty() {
		return faculty;
	}


	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}

    
    
    //Getter and setter:
    //(Getter will reads the value and setter will update the values.)
    
	
	
}
