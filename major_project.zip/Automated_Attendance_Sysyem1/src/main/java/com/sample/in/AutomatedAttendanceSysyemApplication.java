// This is the main file of our project.

package com.sample.in;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//This annotation is combination of three annotation(@Configuration, @EnableAutoConfiguration, and @ComponentScan.)

@SpringBootApplication

public class AutomatedAttendanceSysyemApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomatedAttendanceSysyemApplication.class, args);
	}

}
