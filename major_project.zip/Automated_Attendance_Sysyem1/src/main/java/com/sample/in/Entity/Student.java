package com.sample.in.Entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Student")
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	
//Mapping for subject and student and the created table name is attendance.
//Logic: Many Students can have many subjects and vice versa.
//If we are using many to many mapping, it will create third table automatically which stores the mapped id's.	
	 
	@OneToMany(mappedBy="student",cascade=CascadeType.ALL)
	private List<Attendance>attendances = new ArrayList<>();

	
	 
	@Column(name = "first_name", nullable = false)
	private String firstName;
	
	@Column(name = "last_name")
	private String lastName;
	
	@Column(name = "branch_name")
	private String branchName;
	
	@Column(name = "year")
	private String year;
	
	@Column(name = "batch")
	private String batch;
	
	@Column(name = "semester")
	private String semester;
	
	@Column(name = "academicYear")
	private String academicYear;
	
	@Column(name = "rollNo")
	private String rollNo;
	
	@Column(name = "email")
	private String email;
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "gender")
	private String gender;
	
	@Column(name = "dateOfBirth")
	private String dateOfBirth;

	
//Getter and setter:
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(Long id, Set<Subject> subjects, String firstName, String lastName, String branchName, String year,
			String batch, String semester, String academicYear, String rollNo, String email, String address,
			String gender, String dateOfBirth) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.branchName = branchName;
		this.year = year;
		this.batch = batch;
		this.semester = semester;
		this.academicYear = academicYear;
		this.rollNo = rollNo;
		this.email = email;
		this.address = address;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", branchName=" + branchName + ", year=" + year + ", batch=" + batch + ", semester=" + semester
				+ ", academicYear=" + academicYear + ", rollNo=" + rollNo + ", email=" + email + ", address=" + address
				+ ", gender=" + gender + ", dateOfBirth=" + dateOfBirth + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getBatch() {
		return batch;
	}

	public void setBatch(String batch) {
		this.batch = batch;
	}

	public String getSemester() {
		return semester;
	}

	public void setSemester(String semester) {
		this.semester = semester;
	}

	public String getAcademicYear() {
		return academicYear;
	}

	public void setAcademicYear(String academicYear) {
		this.academicYear = academicYear;
	}

	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

}
