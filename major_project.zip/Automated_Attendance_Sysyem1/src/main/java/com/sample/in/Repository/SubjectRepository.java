package com.sample.in.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sample.in.Entity.Subject;

public interface SubjectRepository extends JpaRepository<Subject, Long>{

}
