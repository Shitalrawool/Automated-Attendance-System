package com.sample.in.Entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "faculty")
public class Faculty {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private Long id;
	
	@Column(name = "faculty_name", nullable = false)
	private String facultyName;
	
	@Column(name = "department")
	private String department;
	
	
	
	@OneToMany(mappedBy="faculty",cascade=CascadeType.ALL)
	private List<Attendance>attendances = new ArrayList<>();



//Getter and setter:

	public Faculty() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Faculty(Long id, String facultyName, String department, List<Subject> subjects) {
		super();
		this.id = id;
		this.facultyName = facultyName;
		this.department = department;

	}
	@Override
	public String toString() {
		return "Faculty [id=" + id + ", facultyName=" + facultyName + ", department=" + department +
				", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFacultyName() {
		return facultyName;
	}

	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
}
