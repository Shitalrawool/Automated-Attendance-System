//here, we have created the services.The business logic resides within the service

package com.sample.in.Service;

import java.util.List;

import com.sample.in.Entity.Attendance;

public interface AttendanceService {
	
	//For Front-end. To link the back end and front-end attendance.
	
	List<Attendance> getAllAttendances();
	
	Attendance saveAttendance(Attendance attendance);
	
	Attendance getAttendanceById(Long id);
	
	Attendance updateAttendance(Attendance attendance);
	
	void deleteAttendanceById(Long id);
	
}
