//Here, we have created controller.
//controller methods are the final destination point that a web request can reach.

package com.sample.in.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.sample.in.Entity.Attendance;
import com.sample.in.Service.AttendanceService;

// It indicates that the annotated class is a controller. 
@Controller

public class AttendanceController {
	
	private AttendanceService attendanceService;

	public AttendanceController(AttendanceService attendanceService) {
		super();
		this.attendanceService = attendanceService;
	}
	
	// handler method to handle list students and return mode and view
	@GetMapping("/attendances")
	public String listAttendances(Model model) {
		model.addAttribute("attendances", attendanceService.getAllAttendances());
		return "attendances";
	}
	
	@GetMapping("/attendances/new")
	public String createAttendanceForm(Model model) {
		
		// create student object to hold student form data
		Attendance attendance = new Attendance();
		model.addAttribute("attendance", attendance);
		return "create_attendance";
		
	}
	
	@PostMapping("/attendances")
	public String saveAttendance(@ModelAttribute("attendance") Attendance attendance) {
		attendanceService.saveAttendance(attendance);
		return "redirect:/attendances";
	}
	
	@GetMapping("/attendances/edit/{id}")
	public String editAttendanceForm(@PathVariable Long id, Model model) {
		model.addAttribute("attendance", attendanceService.getAttendanceById(id));
		return "edit_attendance";
	}

	@PostMapping("/attendances/{id}")
	public String updateAttendance(@PathVariable Long id,
			@ModelAttribute("student") Attendance attendance,
			Model model) {
		
		// get student from database by specific id.
		Attendance existingAttendance = attendanceService.getAttendanceById(id);
		existingAttendance.setId(id);
		existingAttendance.setDateOfLecture(attendance.getDateOfLecture());
		existingAttendance.setTime(attendance.getTime());
		existingAttendance.setStatus(attendance.getStatus());
		
		
		
		existingAttendance.setFaculty(attendance.getFaculty());
		existingAttendance.setSubject(attendance.getSubject());
		existingAttendance.setStudent(attendance.getStudent());
		
		// save updated student object
		attendanceService.updateAttendance(existingAttendance);
		return "redirect:/attendances";		
	}
	
	// handler method to handle delete student request
	
	@GetMapping("/attendances/{id}")
	public String deleteAttendance(@PathVariable Long id) {
		attendanceService.deleteAttendanceById(id);
		return "redirect:/attendances";
	}

}
