package com.sample.in.Entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "subjects")
public class Subject {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "subject_name", nullable = false)
	private String subjectName;
	
	@Column(name = "semester")
	private String semester;
	
	@Column(name = "year")
	private String year;

	
//Mapping for Subject and Faculty.
//Logic:Many subjects can taught by one faculty. 
//FetchType.LAZY:: tells Hibernate to only fetch the related entities from the database when you use the relationship.
	
	@OneToMany(mappedBy="subject",cascade=CascadeType.ALL)
	private List<Attendance>attendances = new ArrayList<>();
	
	
//Getter and Setter:
	
	public Subject() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getSemester() {
		return semester;
	}

	public void setSemester(String semester) {
		this.semester = semester;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	@Override
	public String toString() {
		return "Subject [id=" + id + ", subjectName=" + subjectName + ", semester=" + semester + ", year=" + year
				+ ", getId()=" + getId() + ", getSubjectName()=" + getSubjectName()
				+ ", getSemester()=" + getSemester() + ", getYear()=" + getYear() + 
				", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

	public Subject(Long id, String subjectName, String semester, String year, Faculty faculty) {
		super();
		this.id = id;
		this.subjectName = subjectName;
		this.semester = semester;
		this.year = year;
	}

	
	
}
