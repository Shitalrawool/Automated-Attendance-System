//Service is an interface.
//Service impl implements service class and contains all the logical codes.

package com.sample.in.Service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sample.in.Entity.Attendance;
import com.sample.in.Repository.AttendanceRepository;
import com.sample.in.Service.AttendanceService;

@Service
public class AttendanceServiceImpl implements AttendanceService{

	private AttendanceRepository attendanceRepository;
	
	public AttendanceServiceImpl(AttendanceRepository attendanceRepository) {
		super();
		this.attendanceRepository = attendanceRepository;
	}

	@Override
	public List<Attendance> getAllAttendances() {
		return attendanceRepository.findAll();
	}

	@Override
	public Attendance saveAttendance(Attendance attendance) {
		return attendanceRepository.save(attendance);
	}

	@Override
	public Attendance getAttendanceById(Long id) {
		return attendanceRepository.findById(id).get();
	}

	@Override
	public Attendance updateAttendance(Attendance attendance) {
		return attendanceRepository.save(attendance);
	}

	@Override
	public void deleteAttendanceById(Long id) {
		attendanceRepository.deleteById(id);	
	}

}
