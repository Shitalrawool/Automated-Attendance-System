// Repository used for managing the data in a Spring Boot Application.

package com.sample.in.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sample.in.Entity.Attendance;
import com.sample.in.Entity.Faculty;
import com.sample.in.Entity.Student;
import com.sample.in.Entity.Subject;

//Here we have extends the JpaRepo, because it provides easy maintenance and creation of REST end point.

public interface AttendanceRepository extends JpaRepository<Attendance, Long>{
	List<Attendance>findByFaculty(Faculty faculty);
	List<Attendance>findByStudent(Student student);
	List<Attendance>findBySubject(Subject subject);
}
